package com.infy.model;

public class Admin {
 private String adminName;
 private String adminPassword;
 private String message;
 
public String getAdminName() {
	return adminName;
}
public void setAdminName(String adminName) {
	this.adminName = adminName;
}
public String getAdminPassword() {
	return adminPassword;
}
public void setAdminPassword(String adminPassword) {
	this.adminPassword = adminPassword;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
}
