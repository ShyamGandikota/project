package com.infy.model;

public class ForgotPasswordAdmin {
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminNewPassword() {
		return adminNewPassword;
	}
	public void setAdminNewPassword(String adminNewPassword) {
		this.adminNewPassword = adminNewPassword;
	}
private String adminName;
 private String adminNewPassword;
}
